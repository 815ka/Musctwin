// MusicTwin home page (placeholder)
export default function Home() {
  return <div>MusicTwin Home Page</div>;
}