// MusicTwin result page (placeholder)
export default function Result() {
  return <div>Generated Music Result</div>;
}