# MusicTwin 🎵

AI-powered mood-based music generator built with Next.js and Firebase.