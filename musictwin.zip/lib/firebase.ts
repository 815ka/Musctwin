// Firebase setup (placeholder)
export const db = {};